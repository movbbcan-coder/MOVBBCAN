# MOVBBCAN Trading Bot

MOVBBCAN is a standalone Telegram bot designed for automated trading on the Bybit exchange. This bot implements a grid trading strategy while incorporating advanced features such as auto-trading based on the Relative Strength Index (RSI) and continuous grid cycles.

## Features

- **Grid Trading Logic**: The core functionality of the bot is based on grid trading, allowing users to set up multiple buy and sell orders at predefined intervals.
- **RSI Strategy**: The bot calculates the RSI based on market price data and triggers trades when specific RSI thresholds are met, enhancing trading decisions.
- **Auto-Trading**: Users can enable auto-trading modes that integrate both grid trading and RSI strategies for a more hands-off trading experience.
- **Telegram Integration**: The bot interacts with users through Telegram, providing a user-friendly interface for managing trades and receiving updates.

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/MOVBBCAN.git
   ```

2. Navigate to the project directory:
   ```
   cd MOVBBCAN
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Configure your settings in `src/config/index.ts` (API keys, trading parameters, etc.).

## Usage

To start the bot, run the following command:
```
npm start
```

Once the bot is running, you can interact with it via Telegram. Use commands to set up your trading preferences, check your account status, and manage your trades.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.