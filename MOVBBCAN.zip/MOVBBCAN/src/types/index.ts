export interface User {
    id: string;
    username: string;
    chatId: string;
    preferences: UserPreferences;
}

export interface UserPreferences {
    autoTradeEnabled: boolean;
    rsiThreshold: number;
    gridLevels: number;
    takeProfitPercentage: number;
}

export interface TradingParameters {
    symbol: string;
    gridSize: number;
    gridSpacing: number;
    leverage: number;
}

export interface BotConfig {
    apiKey: string;
    apiSecret: string;
    telegramToken: string;
    tradingParameters: TradingParameters;
}