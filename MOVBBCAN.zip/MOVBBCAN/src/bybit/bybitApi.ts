import axios from 'axios';
import { API_KEY, API_SECRET, BASE_URL } from '../config/index';

const getSignature = (params: any) => {
    const queryString = new URLSearchParams(params).toString();
    const signature = crypto.createHmac('sha256', API_SECRET).update(queryString).digest('hex');
    return signature;
};

export const getMarketData = async (symbol: string) => {
    const params = {
        symbol,
        api_key: API_KEY,
        timestamp: Date.now(),
    };
    params['sign'] = getSignature(params);
    
    try {
        const response = await axios.get(`${BASE_URL}/v2/public/tickers`, { params });
        return response.data;
    } catch (error) {
        console.error('Error fetching market data:', error);
        throw error;
    }
};

export const placeOrder = async (symbol: string, side: string, orderType: string, qty: number, price?: number) => {
    const params = {
        symbol,
        side,
        order_type: orderType,
        qty,
        price,
        api_key: API_KEY,
        timestamp: Date.now(),
    };
    params['sign'] = getSignature(params);
    
    try {
        const response = await axios.post(`${BASE_URL}/v2/private/order/create`, null, { params });
        return response.data;
    } catch (error) {
        console.error('Error placing order:', error);
        throw error;
    }
};

export const getAccountInfo = async () => {
    const params = {
        api_key: API_KEY,
        timestamp: Date.now(),
    };
    params['sign'] = getSignature(params);
    
    try {
        const response = await axios.get(`${BASE_URL}/v2/private/account/info`, { params });
        return response.data;
    } catch (error) {
        console.error('Error fetching account info:', error);
        throw error;
    }
};