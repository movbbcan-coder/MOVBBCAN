import { config } from 'dotenv';

config();

const settings = {
    telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
    bybitApiKey: process.env.BYBIT_API_KEY || '',
    bybitApiSecret: process.env.BYBIT_API_SECRET || '',
    dbConnectionString: process.env.DB_CONNECTION_STRING || '',
    rsiPeriod: parseInt(process.env.RSI_PERIOD) || 14,
    rsiOverbought: parseFloat(process.env.RSI_OVERBOUGHT) || 70,
    rsiOversold: parseFloat(process.env.RSI_OVERSOLD) || 30,
    gridLevels: parseInt(process.env.GRID_LEVELS) || 5,
    gridSpacing: parseFloat(process.env.GRID_SPACING) || 0.01,
    autoTradeEnabled: process.env.AUTO_TRADE_ENABLED === 'true',
};

export default settings;