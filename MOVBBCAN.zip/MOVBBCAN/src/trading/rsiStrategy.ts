import { getRSI } from '../utils/helpers';
import { Order } from '../types/index';

const RSI_PERIOD = 14;
const OVERBOUGHT_THRESHOLD = 70;
const OVERSOLD_THRESHOLD = 30;

export function calculateRSI(prices: number[]): number {
    return getRSI(prices, RSI_PERIOD);
}

export function shouldBuy(rsi: number): boolean {
    return rsi < OVERSOLD_THRESHOLD;
}

export function shouldSell(rsi: number): boolean {
    return rsi > OVERBOUGHT_THRESHOLD;
}

export function executeTrade(order: Order, rsi: number): void {
    if (shouldBuy(rsi)) {
        // Logic to execute buy order
        console.log(`Buying at RSI: ${rsi}`);
    } else if (shouldSell(rsi)) {
        // Logic to execute sell order
        console.log(`Selling at RSI: ${rsi}`);
    }
}