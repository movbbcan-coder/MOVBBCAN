import { Order, GridLevel } from '../types';
import { executeTrade } from '../bybit/bybitApi';

const gridLevels: GridLevel[] = [];
let currentPrice: number = 0;

export function initializeGrid(startPrice: number, gridSize: number, numberOfLevels: number) {
    currentPrice = startPrice;
    for (let i = 0; i < numberOfLevels; i++) {
        gridLevels.push({
            price: currentPrice + (i * gridSize),
            isActive: true,
            order: null
        });
    }
}

export function placeOrders() {
    gridLevels.forEach(level => {
        if (level.isActive && !level.order) {
            level.order = executeTrade(level.price);
        }
    });
}

export function manageGrid(currentMarketPrice: number) {
    currentPrice = currentMarketPrice;
    gridLevels.forEach(level => {
        if (level.isActive && currentPrice >= level.price) {
            level.isActive = false;
            level.order = null; // Reset order after execution
        }
    });
}

export function calculateTakeProfit(entryPrice: number, profitPercentage: number): number {
    return entryPrice * (1 + profitPercentage / 100);
}

export function getActiveGridLevels(): GridLevel[] {
    return gridLevels.filter(level => level.isActive);
}