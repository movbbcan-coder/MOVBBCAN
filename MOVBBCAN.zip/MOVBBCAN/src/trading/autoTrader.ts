import { executeTrade, getMarketData } from '../bybit/bybitApi';
import { calculateRSI } from './rsiStrategy';
import { placeOrder, manageGridLevels } from './gridLogic';
import { TradingMode, TradeParameters } from '../types';
import { getConfig } from '../config/index';

class AutoTrader {
    private tradingMode: TradingMode;
    private tradeParameters: TradeParameters;
    private rsiThreshold: number;
    private gridLevels: number[];

    constructor() {
        this.tradingMode = TradingMode.GRID; // Default mode
        this.tradeParameters = getConfig().tradeParameters;
        this.rsiThreshold = getConfig().rsiThreshold;
        this.gridLevels = [];
    }

    public start() {
        this.initializeGrid();
        this.monitorMarket();
    }

    private initializeGrid() {
        this.gridLevels = manageGridLevels(this.tradeParameters);
    }

    private monitorMarket() {
        setInterval(async () => {
            const marketData = await getMarketData();
            this.executeTradingLogic(marketData);
        }, this.tradeParameters.checkInterval);
    }

    private executeTradingLogic(marketData: any) {
        const rsi = calculateRSI(marketData.prices);
        
        if (this.tradingMode === TradingMode.RSI && rsi < this.rsiThreshold) {
            this.placeTrade();
        } else if (this.tradingMode === TradingMode.GRID) {
            this.placeGridTrades();
        }
    }

    private placeTrade() {
        executeTrade(this.tradeParameters);
    }

    private placeGridTrades() {
        this.gridLevels.forEach(level => {
            placeOrder(level, this.tradeParameters);
        });
    }

    public setTradingMode(mode: TradingMode) {
        this.tradingMode = mode;
    }
}

export default AutoTrader;