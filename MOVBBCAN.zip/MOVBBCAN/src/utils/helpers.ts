import { format } from 'date-fns';

export const formatDate = (date: Date, formatString: string): string => {
    return format(date, formatString);
};

export const logMessage = (message: string): void => {
    console.log(`[${new Date().toISOString()}] ${message}`);
};

export const calculatePercentage = (part: number, total: number): number => {
    if (total === 0) return 0;
    return (part / total) * 100;
};

export const sleep = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
};