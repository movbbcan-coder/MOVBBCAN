import TelegramBot, { Message } from 'node-telegram-bot-api';
import settings from '../config';

// Minimal, working Telegram bot skeleton using node-telegram-bot-api
// Implements basic commands and stubs for Bybit connect and bot creation flows.

const token = settings.telegramBotToken;
if (!token) {
  console.error('TELEGRAM_BOT_TOKEN is not set in environment (.env)');
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

// Simple in-memory session to guide basic flows (temporary until DB is wired)
const sessions = new Map<number, { expect?: 'bybitKeys'; pendingPromptMsgId?: number }>();

// Helpers
const replyMainMenu = (chatId: number) => {
  bot.sendMessage(chatId, 'Выберите действие:', {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🔑 Подключить Bybit', callback_data: 'connect_bybit' },
          { text: '🤖 Новый бот', callback_data: 'new_bot' }
        ],
        [
          { text: '📋 Мои боты', callback_data: 'my_bots' },
          { text: '📈 Статистика', callback_data: 'stats' }
        ],
        [
          { text: '❓ Помощь', callback_data: 'help' }
        ]
      ]
    }
  });
};

// /start
bot.onText(/^\/start\b/i, (msg) => {
  const chatId = msg.chat.id;
  const text = [
    'Привет! Это MOVBBCAN — Telegram-бот для торговли на Bybit.',
    'UI полностью в Telegram: создавайте сетки (лонг/шорт), настраивайте TP, мартингейл и автоторговлю по RSI или непрерывный режим.',
    'Начнём?'
  ].join('\n');
  bot.sendMessage(chatId, text).then(() => replyMainMenu(chatId));
});

// /help
bot.onText(/^\/help\b/i, (msg) => {
  const chatId = msg.chat.id;
  const help = [
    'Доступные команды:',
    '/start — главное меню',
    '/connect_bybit — подключить API Bybit (ключ/секрет)',
    '/new_bot — мастер создания торгового бота',
    '/my_bots — список ваших ботов',
    '/stats — история PnL и CSV'
  ].join('\n');
  bot.sendMessage(chatId, help);
});

// Aliases for spec-style "/user ..." commands
bot.onText(/^\/user\s*(.*)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const arg = (match?.[1] || '').trim().toLowerCase();
  if (arg.startsWith('start')) return bot.emit('text', msg as any);
  if (arg.startsWith('connect_bybit')) return handleConnectBybit(chatId);
  if (arg.startsWith('new_bot')) return handleNewBot(chatId);
  replyMainMenu(chatId);
});

// Command shortcuts
bot.onText(/^\/connect_bybit\b/i, (msg) => handleConnectBybit(msg.chat.id));
bot.onText(/^\/new_bot\b/i, (msg) => handleNewBot(msg.chat.id));
bot.onText(/^\/my_bots\b/i, (msg) => bot.sendMessage(msg.chat.id, 'Мои боты: (пока пусто)'));
bot.onText(/^\/stats\b/i, (msg) => bot.sendMessage(msg.chat.id, 'Статистика: (в разработке)'));

// Inline button callbacks
bot.on('callback_query', (q) => {
  const chatId = q.message?.chat.id;
  const data = q.data;
  if (!chatId || !data) return;

  switch (data) {
    case 'help':
      bot.answerCallbackQuery(q.id);
      bot.emit('text', { chat: { id: chatId } } as unknown as Message);
      break;
    case 'connect_bybit':
      bot.answerCallbackQuery(q.id);
      handleConnectBybit(chatId);
      break;
    case 'new_bot':
      bot.answerCallbackQuery(q.id);
      handleNewBot(chatId);
      break;
    case 'my_bots':
      bot.answerCallbackQuery(q.id);
      bot.sendMessage(chatId, 'Мои боты: (пока пусто)');
      break;
    case 'stats':
      bot.answerCallbackQuery(q.id);
      bot.sendMessage(chatId, 'Статистика: (в разработке)');
      break;
    default:
      bot.answerCallbackQuery(q.id);
      break;
  }
});

// Bybit connect flow (stub, with message cleanup)
function handleConnectBybit(chatId: number) {
  const prompt = [
    'Подключение Bybit:',
    'Отправьте одним сообщением: API_KEY;API_SECRET',
    'Пример: abc123;def456',
    'Внимание: мы удалим это сообщение после обработки. В проде ключи шифруются и сохраняются в БД.'
  ].join('\n');

  bot.sendMessage(chatId, prompt, { disable_web_page_preview: true }).then((m) => {
    sessions.set(chatId, { expect: 'bybitKeys', pendingPromptMsgId: m.message_id });
  });
}

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const state = sessions.get(chatId);
  if (!state?.expect) return; // no pending flow

  if (state.expect === 'bybitKeys' && typeof msg.text === 'string') {
    const [apiKey, apiSecret] = msg.text.split(';').map((s) => s.trim());
    if (apiKey && apiSecret) {
      // TODO: encrypt and persist to DB. For now, confirm and clean up.
      bot.sendMessage(chatId, 'Ключи получены. Подключение будет сохранено (заглушка).');
      // delete user message with keys
      bot.deleteMessage(chatId, String(msg.message_id)).catch(() => {});
      // delete our prompt if exists
      if (state.pendingPromptMsgId) bot.deleteMessage(chatId, String(state.pendingPromptMsgId)).catch(() => {});
      sessions.delete(chatId);
      replyMainMenu(chatId);
    } else {
      bot.sendMessage(chatId, 'Формат не распознан. Пожалуйста, отправьте: API_KEY;API_SECRET');
    }
  }
});

// New bot creation flow (very first step stub)
function handleNewBot(chatId: number) {
  const text = 'Выберите источник сигнала:';
  bot.sendMessage(chatId, text, {
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'TradingView Alert', callback_data: 'mode_tradingview' },
          { text: 'RSI Auto-Trading', callback_data: 'mode_rsi' },
          { text: 'Continuous Grid', callback_data: 'mode_continuous' }
        ]
      ]
    }
  });
}

console.log('Telegram bot polling started.');